/// Modèle de joueur pour le jeu Ibizungu

class Player {
  final String id;
  final String pseudo;
  final int ddkBalance;
  final bool isHost;
  final String? teamId;
  bool isReady;
  bool isConnected;

  Player({
    required this.id,
    required this.pseudo,
    this.ddkBalance = 1000,
    this.isHost = false,
    this.teamId,
    this.isReady = false,
    this.isConnected = true,
  });

  /// Met à jour le solde DDK
  Player copyWith({
    String? id,
    String? pseudo,
    int? ddkBalance,
    bool? isHost,
    String? teamId,
    bool? isReady,
    bool? isConnected,
  }) {
    return Player(
      id: id ?? this.id,
      pseudo: pseudo ?? this.pseudo,
      ddkBalance: ddkBalance ?? this.ddkBalance,
      isHost: isHost ?? this.isHost,
      teamId: teamId ?? this.teamId,
      isReady: isReady ?? this.isReady,
      isConnected: isConnected ?? this.isConnected,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'pseudo': pseudo,
    'ddkBalance': ddkBalance,
    'isHost': isHost,
    'teamId': teamId,
    'isReady': isReady,
    'isConnected': isConnected,
  };

  factory Player.fromJson(Map<String, dynamic> json) {
    return Player(
      id: json['id'] as String,
      pseudo: json['pseudo'] as String,
      ddkBalance: json['ddkBalance'] as int? ?? 1000,
      isHost: json['isHost'] as bool? ?? false,
      teamId: json['teamId'] as String?,
      isReady: json['isReady'] as bool? ?? false,
      isConnected: json['isConnected'] as bool? ?? true,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Player && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() => 'Player($pseudo, DDK: $ddkBalance)';
}
