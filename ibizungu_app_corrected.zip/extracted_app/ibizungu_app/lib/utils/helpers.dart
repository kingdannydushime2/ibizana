import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// Fonctions utilitaires pour l'application
class Helpers {
  /// Formate un montant DDK
  static String formatDDK(int amount) {
    final formatter = NumberFormat('#,###');
    return '${formatter.format(amount)} DDK';
  }

  /// Formate une date
  static String formatDate(DateTime date) {
    return DateFormat('dd/MM/yyyy HH:mm').format(date);
  }

  /// Formate une date relative
  static String formatRelativeDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      if (difference.inHours == 0) {
        return 'Il y a ${difference.inMinutes} min';
      }
      return 'Il y a ${difference.inHours}h';
    } else if (difference.inDays == 1) {
      return 'Hier';
    } else if (difference.inDays < 7) {
      return 'Il y a ${difference.inDays} jours';
    } else {
      return DateFormat('dd MMM').format(date);
    }
  }

  /// Obtient la couleur d'un résultat
  static Color getResultColor(String result) {
    switch (result.toLowerCase()) {
      case 'win':
        return Colors.green;
      case 'lose':
        return Colors.red;
      case 'cancelled':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  /// Obtient l'icône d'un résultat
  static IconData getResultIcon(String result) {
    switch (result.toLowerCase()) {
      case 'win':
        return Icons.emoji_events;
      case 'lose':
        return Icons.sentiment_dissatisfied;
      case 'cancelled':
        return Icons.cancel;
      default:
        return Icons.help;
    }
  }

  /// Génère un code QR pour les DDK
  static String generateDDKTransferCode(String senderId, String recipientId, int amount, {String? senderPseudo}) {
    // Format: IBZUNG:senderId:recipientId:amount:timestamp:senderPseudo
    final pseudo = senderPseudo ?? '';
    return 'IBZUNG:${senderId}:${recipientId}:$amount:${DateTime.now().millisecondsSinceEpoch}:$pseudo';
  }

  /// Parse un code de transfert DDK
  static Map<String, dynamic>? parseDDKTransferCode(String code) {
    if (!code.startsWith('IBZUNG:')) return null;

    final parts = code.split(':');
    if (parts.length < 5) return null;

    // Support both old format (5 parts) and new format (6 parts with pseudo)
    if (parts.length == 5) {
      return {
        'senderId': parts[1],
        'recipientId': parts[2],
        'amount': int.tryParse(parts[3]) ?? 0,
        'timestamp': int.tryParse(parts[4]) ?? 0,
        'senderPseudo': '',
      };
    }

    return {
      'senderId': parts[1],
      'recipientId': parts[2],
      'amount': int.tryParse(parts[3]) ?? 0,
      'timestamp': int.tryParse(parts[4]) ?? 0,
      'senderPseudo': parts.length > 5 ? parts[5] : '',
    };
  }

  /// Vérifie si un code de transfert est expiré (2 minutes)
  static bool isTransferCodeExpired(int timestamp) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final twoMinutes = 2 * 60 * 1000;
    return now - timestamp > twoMinutes;
  }
}
