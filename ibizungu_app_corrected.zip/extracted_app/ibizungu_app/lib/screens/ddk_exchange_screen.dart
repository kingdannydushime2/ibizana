import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/services.dart';
import '../utils/theme.dart';
import '../utils/helpers.dart';

/// Écran d'échange DDK -> FBU (Lumicash)
class DdkExchangeScreen extends StatefulWidget {
  const DdkExchangeScreen({super.key});

  @override
  State<DdkExchangeScreen> createState() => _DdkExchangeScreenState();
}

class _DdkExchangeScreenState extends State<DdkExchangeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  bool _isLoading = false;

  static const int exchangeRate = 10000; // 10 000 DDK = 5 000 FBU
  static const int fbuAmount = 5000;

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _processExchange() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final storageService = context.read<StorageService>();
      final currentBalance = storageService.getDdkBalance();

      if (currentBalance < exchangeRate) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Solde insuffisant (minimum $exchangeRate DDK)'),
              backgroundColor: AppTheme.error,
            ),
          );
        }
        return;
      }

      // Déduit les DDK
      await storageService.saveDdkBalance(currentBalance - exchangeRate);

      if (mounted) {
        // Affiche le message de succès
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Row(
              children: [
                const Icon(Icons.check_circle, color: AppTheme.success),
                const SizedBox(width: 8),
                const Text('Opération confirmée !'),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppTheme.success.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        '10 000 DDK',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.error,
                        ),
                      ),
                      const Icon(Icons.arrow_downward, color: Colors.white54),
                      Text(
                        '$fbuAmount FBU',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.success,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  '$fbuAmount FBU seront crédités sur votre compte Lumicash.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
            actions: [
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur: $e')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final storageService = context.watch<StorageService>();
    final balance = storageService.getDdkBalance();
    final canExchange = balance >= exchangeRate;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Gagner de l\'argent'),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              AppTheme.backgroundDark,
              AppTheme.primaryDark,
            ],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Solde actuel
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.account_balance_wallet),
                        const SizedBox(width: 12),
                        Text(
                          'Solde: ${Helpers.formatDDK(balance)}',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                // Taux d'échange
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        AppTheme.primaryGold.withValues(alpha: 0.2),
                        AppTheme.primaryGold.withValues(alpha: 0.1),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: AppTheme.primaryGold.withValues(alpha: 0.5),
                    ),
                  ),
                  child: Column(
                    children: [
                      const Icon(
                        Icons.currency_exchange,
                        size: 48,
                        color: AppTheme.primaryGold,
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'Taux d\'échange',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.white70,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            '$exchangeRate DDK',
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: AppTheme.error,
                            ),
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 16),
                            child: Icon(Icons.arrow_forward, color: Colors.white54),
                          ),
                          Text(
                            '$fbuAmount FBU',
                            style: const TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              color: AppTheme.success,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                // Numéro Lumicash
                TextFormField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Ton numéro Lumicash',
                    hintText: 'Ex: 6XXXXXXXX',
                    prefixIcon: Icon(Icons.phone, color: AppTheme.primaryGold),
                  ),
                  keyboardType: TextInputType.phone,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Veuillez entrer votre numéro Lumicash';
                    }
                    if (!RegExp(r'^[67]\d{8}$').hasMatch(value.trim())) {
                      return 'Numéro invalide (doit commencer par 6 ou 7)';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                // Bouton échanger
                ElevatedButton.icon(
                  icon: _isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.swap_horiz),
                  label: const Text('Valider l\'échange'),
                  onPressed: canExchange && !_isLoading ? _processExchange : null,
                ),
                if (!canExchange) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.error.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: AppTheme.error.withValues(alpha: 0.5),
                      ),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.warning, color: AppTheme.error),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Solde insuffisant (minimum $exchangeRate DDK)',
                            style: const TextStyle(color: AppTheme.error),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
