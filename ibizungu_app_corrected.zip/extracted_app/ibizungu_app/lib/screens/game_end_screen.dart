import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../services/services.dart';
import '../utils/theme.dart';

/// Écran de fin de partie avec effets win/lose
class GameEndScreen extends StatefulWidget {
  final String? winnerId;
  final String message;
  final GameMode mode;
  final int potAmount;

  const GameEndScreen({
    super.key,
    this.winnerId,
    required this.message,
    required this.mode,
    required this.potAmount,
  });

  @override
  State<GameEndScreen> createState() => _GameEndScreenState();
}

class _GameEndScreenState extends State<GameEndScreen> with SingleTickerProviderStateMixin {
  late AnimationController _confettiController;
  bool _isWinner = false;
  String? _winnerName;

  @override
  void initState() {
    super.initState();
    _confettiController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );
    _confettiController.repeat();
    
    _checkWinner();
  }

  Future<void> _checkWinner() async {
    final storageService = context.read<StorageService>();
    final currentPlayerId = storageService.getPlayerId();

    setState(() {
      // En Mode Groupes, winnerId est l'ID de l'équipe (ex: "team_1")
      // On vérifie si le joueur appartient à l'équipe gagnante
      if (widget.mode == GameMode.groups) {
        // Récupère le GameService pour obtenir l'équipe du joueur
        final gameService = context.read<GameService>();
        final state = gameService.gameState;
        if (state != null && widget.winnerId != null) {
          // Trouve l'équipe du joueur actuel
          for (var player in state.players) {
            if (player.id == currentPlayerId && player.teamId != null) {
              _isWinner = player.teamId == widget.winnerId;
              break;
            }
          }
        }
        _winnerName = 'Votre équipe';
      } else {
        // Mode Individuel: comparaison directe des IDs
        _isWinner = widget.winnerId == currentPlayerId;

        // Récupère le nom du winner
        final gameService = context.read<GameService>();
        final state = gameService.gameState;
        if (state != null) {
          final winner = state.players.firstWhere(
            (p) => p.id == widget.winnerId,
            orElse: () => Player(id: '', pseudo: 'Inconnu'),
          );
          _winnerName = winner.pseudo;
        }
      }
    });

    // BUG FIX: Les DDK sont maintenant gérés UNIQUEMENT par le GameService
    // via _distributePotToWinner(). Le crédit ici causerait un double crédit!
    // On ajoute seulement à l'historique pour le suivi
    if (_isWinner && widget.potAmount > 0) {
      await storageService.addToHistory(GameHistoryEntry(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        roomCode: 'local',
        mode: widget.mode.name,
        playerCount: context.read<GameService>().gameState?.players.length ?? 0,
        result: 'win',
        ddkWon: widget.potAmount,
        date: DateTime.now(),
      ));
      debugPrint('Gain enregistré dans l\'historique: +${widget.potAmount} DDK');
    }
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: _isWinner
                ? [
                    AppTheme.pokerGreen,
                    const Color(0xFF0D3D1C),
                  ]
                : [
                    const Color(0xFF2D1B1B),
                    const Color(0xFF1A0A0A),
                  ],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              // Particules dorées (animation)
              ..._buildParticles(),
              
              // Contenu principal
              Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Icône de résultat
                    _buildResultIcon()
                        .animate()
                        .scale(
                          begin: const Offset(0, 0),
                          end: const Offset(1, 1),
                          duration: 600.ms,
                          curve: Curves.elasticOut,
                        )
                        .then()
                        .shimmer(
                          duration: 1500.ms,
                          color: _isWinner
                              ? AppTheme.primaryGold.withValues(alpha: 0.5)
                              : Colors.red.withValues(alpha: 0.3),
                        ),
                    
                    const SizedBox(height: 32),
                    
                    // Titre
                    Text(
                      _isWinner ? 'VICTOIRE !' : 'DÉFAITE',
                      style: TextStyle(
                        fontSize: 48,
                        fontWeight: FontWeight.bold,
                        color: _isWinner ? AppTheme.primaryGold : AppTheme.error,
                        letterSpacing: 4,
                        shadows: [
                          Shadow(
                            color: _isWinner
                                ? AppTheme.primaryGold.withValues(alpha: 0.5)
                                : AppTheme.error.withValues(alpha: 0.5),
                            blurRadius: 20,
                          ),
                        ],
                      ),
                    )
                        .animate()
                        .fadeIn(duration: 500.ms)
                        .slideY(begin: 0.3, end: 0),
                    
                    const SizedBox(height: 24),
                    
                    // Message
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 32,
                        vertical: 16,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: _isWinner
                              ? AppTheme.primaryGold.withValues(alpha: 0.5)
                              : AppTheme.error.withValues(alpha: 0.3),
                        ),
                      ),
                      child: Text(
                        widget.message,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          color: _isWinner ? Colors.white : Colors.white70,
                        ),
                      ),
                    )
                        .animate()
                        .fadeIn(delay: 300.ms),
                    
                    const SizedBox(height: 32),
                    
                    // Gains/pertes
                    if (_isWinner)
                      _buildWinSection()
                    else
                      _buildLoseSection(),
                    
                    const SizedBox(height: 48),
                    
                    // Boutons
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        OutlinedButton.icon(
                          onPressed: () {
                            Navigator.of(context).pushReplacementNamed('/home');
                          },
                          icon: const Icon(Icons.home),
                          label: const Text('Accueil'),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 12,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        ElevatedButton.icon(
                          onPressed: () {
                            Navigator.of(context).pushReplacementNamed(
                              '/game-lobby',
                              arguments: {'isHost': true, 'mode': widget.mode.name},
                            );
                          },
                          icon: const Icon(Icons.replay),
                          label: const Text('Rejouer'),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 24,
                              vertical: 12,
                            ),
                          ),
                        ),
                      ],
                    )
                        .animate()
                        .fadeIn(delay: 800.ms)
                        .slideY(begin: 0.5, end: 0),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultIcon() {
    return Container(
      width: 150,
      height: 150,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: _isWinner
              ? [
                  AppTheme.primaryGold,
                  AppTheme.primaryGold.withValues(alpha: 0.7),
                ]
              : [
                  AppTheme.error,
                  AppTheme.error.withValues(alpha: 0.7),
                ],
        ),
        boxShadow: [
          BoxShadow(
            color: (_isWinner ? AppTheme.primaryGold : AppTheme.error)
                .withValues(alpha: 0.5),
            blurRadius: 30,
            spreadRadius: 10,
          ),
        ],
      ),
      child: Icon(
        _isWinner ? Icons.emoji_events : Icons.sentiment_dissatisfied,
        size: 80,
        color: Colors.white,
      ),
    );
  }

  Widget _buildWinSection() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.success.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.success),
      ),
      child: Column(
        children: [
          const Text(
            'Vous avez gagné !',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppTheme.success,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.monetization_on,
                color: AppTheme.primaryGold,
                size: 32,
              ),
              const SizedBox(width: 8),
              Text(
                '+${widget.potAmount} DDK',
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryGold,
                ),
              ),
            ],
          ),
        ],
      ),
    ).animate().fadeIn(delay: 500.ms).scale(begin: const Offset(0.8, 0.8));
  }

  Widget _buildLoseSection() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.error.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.error.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          const Text(
            'Dommage !',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppTheme.error,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Vous avez perdu votre mise.',
            style: TextStyle(color: Colors.white70),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 500.ms);
  }

  List<Widget> _buildParticles() {
    final particles = <Widget>[];
    
    if (_isWinner) {
      // Crée des particules dorées pour la victoire
      for (int i = 0; i < 20; i++) {
        particles.add(
          Positioned(
            left: (i * 50.0) % MediaQuery.of(context).size.width,
            top: 0,
            child: _buildGoldParticle(i),
          ),
        );
      }
    }
    
    return particles;
  }

  Widget _buildGoldParticle(int index) {
    return Container(
      width: 8,
      height: 8,
      decoration: BoxDecoration(
        color: AppTheme.primaryGold,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryGold.withValues(alpha: 0.5),
            blurRadius: 4,
          ),
        ],
      ),
    )
        .animate(
          onPlay: (controller) => controller.repeat(),
        )
        .moveY(
          begin: -100,
          end: MediaQuery.of(context).size.height + 100,
          duration: Duration(milliseconds: 2000 + (index * 200)),
          curve: Curves.easeIn,
        )
        .fadeOut(
          delay: Duration(milliseconds: 1500 + (index * 200)),
        );
  }
}
