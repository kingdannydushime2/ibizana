import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'socket_message.dart';

/// Client Socket pour rejoindre une room en tant que joueur
class IbizunguSocketClient {
  Socket? _socket;
  String? _hostAddress;
  int? _port;
  String? _roomCode;
  GameParticipant? _currentParticipant;

  bool _isConnected = false;
  bool _isConnecting = false;

  // Callbacks pour les événements
  Function(GameParticipant)? onJoined;
  Function(List<GameParticipant>)? onParticipantsUpdated;
  Function(Map<String, dynamic>)? onGameStateReceived;
  Function(Map<String, dynamic>)? onGameStart;
  Function(String, String, int, Map<String, dynamic>?)? onGameOver;
  Function(bool)? onRoomReady;
  Function()? onRoomClosed;
  Function(String)? onParticipantJoined;
  Function(String)? onParticipantLeft;
  Function()? onDisconnected;
  Function(String)? onError;

  bool get isConnected => _isConnected;
  bool get isConnecting => _isConnecting;
  String? get roomCode => _roomCode;
  GameParticipant? get currentParticipant => _currentParticipant;

  /// Se connecte à l'hôte
  Future<bool> connect(String hostAddress, int port, String roomCode, GameParticipant participant) async {
    if (_isConnecting || _isConnected) {
      debugPrint('Déjà connecté ou en cours de connexion');
      return false;
    }

    _hostAddress = hostAddress;
    _port = port;
    _roomCode = roomCode;
    _currentParticipant = participant;
    _isConnecting = true;

    try {
      _socket = await Socket.connect(
        hostAddress,
        port,
        timeout: const Duration(seconds: 10),
      );

      _isConnected = true;
      _isConnecting = false;

      // Envoie le message de join
      _sendMessage({
        'type': 'join',
        'path': '/room/join',
        'data': {
          'participant': participant.toJson(),
          'roomCode': roomCode,
        },
      });

      // Écoute les messages de l'hôte
      _listenToServer();

      debugPrint('Connecté au serveur: $hostAddress:$port');
      return true;
    } catch (e) {
      debugPrint('Erreur connexion: $e');
      _isConnecting = false;
      _isConnected = false;
      onError?.call('Erreur de connexion: $e');
      return false;
    }
  }

  /// Se déconnecte du serveur
  Future<void> disconnect() async {
    if (_socket != null) {
      // Envoie le message de leave
      if (_currentParticipant != null && _roomCode != null) {
        _sendMessage({
          'type': 'leave',
          'path': '/room/leave',
          'data': {
            'participantId': _currentParticipant!.id,
            'roomCode': _roomCode,
          },
        });
      }

      try {
        await _socket!.close();
      } catch (e) {
        debugPrint('Erreur fermeture socket: $e');
      }
    }

    _socket = null;
    _isConnected = false;
    _isConnecting = false;
    _hostAddress = null;
    _port = null;
    _roomCode = null;
    _currentParticipant = null;

    debugPrint('Déconnecté du serveur');
  }

  /// Envoie un message au serveur
  void _sendMessage(Map<String, dynamic> message) {
    if (_socket != null && _isConnected) {
      try {
        _socket!.write(jsonEncode(message));
      } catch (e) {
        debugPrint('Erreur envoi message: $e');
      }
    }
  }

  /// Écoute les messages du serveur
  void _listenToServer() {
    _socket?.listen(
      (data) {
        try {
          final messageString = utf8.decode(data);
          final message = jsonDecode(messageString) as Map<String, dynamic>;
          _handleMessage(message);
        } catch (e) {
          debugPrint('Erreur décodage message: $e');
        }
      },
      onError: (error) {
        debugPrint('Erreur socket: $error');
        _handleDisconnection();
      },
      onDone: () {
        debugPrint('Connexion fermée par le serveur');
        _handleDisconnection();
      },
    );
  }

  /// Gère les messages reçus
  void _handleMessage(Map<String, dynamic> message) {
    final type = message['type'] as String?;
    final path = message['path'] as String?;
    final data = message['data'] as Map<String, dynamic>?;

    debugPrint('Message reçu: $type - $path');

    switch (type) {
      case 'join_ack':
        _handleJoinAck(data);
        break;

      case 'pong':
        // Réponse au ping - ignore, le scan est déjà complet
        debugPrint('Pong reçu');
        break;

      case 'participant_joined':
        _handleParticipantJoined(data);
        break;

      case 'participant_left':
        _handleParticipantLeft(data);
        break;

      case 'participants_update':
      case 'participants_update_full':
        _handleParticipantsUpdate(data);
        break;

      case 'game_state':
        _handleGameState(data);
        break;

      case 'game_start':
        _handleGameStart(data);
        break;

      case 'game_over':
        _handleGameOver(data);
        break;

      case 'room_ready':
        _handleRoomReady(data);
        break;

      case 'room_closed':
        _handleRoomClosed(data);
        break;

      case 'error':
        _handleError(data);
        break;

      default:
        debugPrint('Type de message inconnu: $type');
    }
  }

  /// Gère la réponse de join
  void _handleJoinAck(Map<String, dynamic>? data) {
    if (data == null) return;

    try {
      final ack = ConnectionAckMessage.fromJson(data);

      if (ack.success) {
        _currentParticipant = ack.participant;

        // Notifie le callback
        if (ack.participant != null) {
          onJoined?.call(ack.participant!);
        }

        // Met à jour les participants
        if (ack.existingParticipants != null) {
          onParticipantsUpdated?.call(ack.existingParticipants!);
        }

        // Si un état de jeu est inclus (jeu déjà en cours), met à jour le GameService
        if (ack.gameState != null && ack.gameState!.isNotEmpty) {
          debugPrint('État du jeu reçu lors du join: gameState présent');
          onGameStateReceived?.call(ack.gameState!);
        }
      } else {
        onError?.call(ack.error ?? 'Erreur de connexion');
      }
    } catch (e) {
      debugPrint('Erreur parsing join_ack: $e');
    }
  }

  /// Gère l'ajout d'un participant
  void _handleParticipantJoined(Map<String, dynamic>? data) {
    if (data == null) return;

    final participantId = data['participantId'] as String?;
    if (participantId != null) {
      onParticipantJoined?.call(participantId);
    }

    // Met à jour les participants
    if (data['participants'] != null) {
      final participants = (data['participants'] as List)
          .map((p) => GameParticipant.fromJson(p as Map<String, dynamic>))
          .toList();
      onParticipantsUpdated?.call(participants);
    }
  }

  /// Gère le départ d'un participant
  void _handleParticipantLeft(Map<String, dynamic>? data) {
    if (data == null) return;

    final participantId = data['participantId'] as String?;
    if (participantId != null) {
      onParticipantLeft?.call(participantId);
    }

    // Met à jour les participants
    if (data['participants'] != null) {
      final participants = (data['participants'] as List)
          .map((p) => GameParticipant.fromJson(p as Map<String, dynamic>))
          .toList();
      onParticipantsUpdated?.call(participants);
    }
  }

  /// Gère la mise à jour des participants
  void _handleParticipantsUpdate(Map<String, dynamic>? data) {
    if (data == null) return;

    final participants = (data['participants'] as List)
        .map((p) => GameParticipant.fromJson(p as Map<String, dynamic>))
        .toList();
    onParticipantsUpdated?.call(participants);
  }

  /// Gère la réception de l'état du jeu
  void _handleGameState(Map<String, dynamic>? data) {
    if (data == null) return;

    try {
      final gameState = data['gameState'] as Map<String, dynamic>?;
      if (gameState != null) {
        onGameStateReceived?.call(gameState);
      }
    } catch (e) {
      debugPrint('Erreur parsing game_state: $e');
    }
  }

  /// Gère le démarrage du jeu
  void _handleGameStart(Map<String, dynamic>? data) {
    if (data == null) return;

    try {
      final gameStart = GameStartMessage.fromJson(data);
      final initialState = gameStart.initialGameState;
      onGameStart?.call(initialState ?? {});
    } catch (e) {
      debugPrint('Erreur parsing game_start: $e');
      onGameStart?.call({});
    }
  }

  /// Gère la fin du jeu
  void _handleGameOver(Map<String, dynamic>? data) {
    if (data == null) return;

    try {
      final gameOver = GameOverMessage.fromJson(data);
      onGameOver?.call(
        gameOver.winnerId ?? '',
        gameOver.message ?? 'Partie terminée',
        gameOver.potAmount,
        gameOver.finalState,
      );
    } catch (e) {
      debugPrint('Erreur parsing game_over: $e');
    }
  }

  /// Gère le message de room prête
  void _handleRoomReady(Map<String, dynamic>? data) {
    if (data == null) return;

    try {
      final ready = RoomReadyMessage.fromJson(data);
      onRoomReady?.call(ready.isReady);
    } catch (e) {
      debugPrint('Erreur parsing room_ready: $e');
    }
  }

  /// Gère la fermeture de la room
  void _handleRoomClosed(Map<String, dynamic>? data) {
    try {
      final closed = RoomClosedMessage.fromJson(data ?? {});
      debugPrint('Room fermée: ${closed.reason}');
    } catch (e) {
      debugPrint('Erreur parsing room_closed: $e');
    }
    onRoomClosed?.call();
  }

  /// Gère les erreurs
  void _handleError(Map<String, dynamic>? data) {
    final error = data?['error'] as String? ?? 'Erreur inconnue';
    onError?.call(error);
  }

  /// Gère la déconnexion
  void _handleDisconnection() {
    _isConnected = false;
    _isConnecting = false;
    onDisconnected?.call();
  }

  /// Demande l'état actuel du jeu
  void requestGameState() {
    _sendMessage({
      'type': 'request_state',
      'path': '/game/request_state',
      'data': {
        'participantId': _currentParticipant?.id,
      },
    });
  }

  /// Envoie une action de jeu
  void sendGameAction(String actionType, Map<String, dynamic>? actionData) {
    _sendMessage({
      'type': 'game_action',
      'path': '/game/action',
      'data': GameActionMessage(
        participantId: _currentParticipant?.id ?? '',
        actionType: actionType,
        actionData: actionData,
      ).toJson(),
    });
  }

  /// Nettoie les ressources
  Future<void> dispose() async {
    await disconnect();
  }
}
