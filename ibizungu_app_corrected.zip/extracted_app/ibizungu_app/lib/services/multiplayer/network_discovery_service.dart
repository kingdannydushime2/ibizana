import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';

/// Result of a discovered game room on the network
class DiscoveredRoom {
  final String ipAddress;
  final int port;
  final String? roomCode;
  final String? hostName;
  final DateTime discoveredAt;

  DiscoveredRoom({
    required this.ipAddress,
    required this.port,
    this.roomCode,
    this.hostName,
    DateTime? discoveredAt,
  }) : discoveredAt = discoveredAt ?? DateTime.now();

  @override
  String toString() => 'DiscoveredRoom($ipAddress:$port, roomCode: $roomCode)';
}

/// Service pour découvrir les salles de jeu Ibizungu sur le réseau local
/// Utilise le broadcast UDP pour détecter les serveurs disponibles
class NetworkDiscoveryService {
  static const int broadcastPort = 8081; // Port pour la découverte UDP
  static const Duration scanTimeout = Duration(seconds: 3);
  static const String broadcastIdentifier = 'IBZUNG_DISCOVER';

  RawDatagramSocket? _socket;
  final List<DiscoveredRoom> _discoveredRooms = [];
  final Map<String, DateTime> _lastSeen = {};
  bool _isScanning = false;

  // Callback pour les salles découvertes
  Function(DiscoveredRoom)? onRoomDiscovered;
  Function(String)? onRoomRemoved;

  bool get isScanning => _isScanning;
  List<DiscoveredRoom> get discoveredRooms => List.unmodifiable(_discoveredRooms);

  /// Démarre le scan du réseau local
  Future<void> startScan() async {
    if (_isScanning) return;
    _isScanning = true;
    _discoveredRooms.clear();

    try {
      // Bind sur le port de broadcast
      _socket = await RawDatagramSocket.bind(
        InternetAddress.anyIPv4,
        broadcastPort,
        reuseAddress: true,
        reusePort: true,
      );

      _socket!.broadcastEnabled = true;

      // Écoute les réponses
      _socket!.listen((event) {
        if (event == RawSocketEvent.read) {
          final datagram = _socket!.receive();
          if (datagram != null) {
            _handleDiscoveryResponse(datagram);
          }
        }
      });

      // Envoie une requête de broadcast
      await _sendBroadcast();

      // Nettoie les salles anciennes après le timeout
      _startCleanupTimer();

    } catch (e) {
      debugPrint('Erreur scan réseau: $e');
      _isScanning = false;
    }
  }

  /// Arrête le scan
  void stopScan() {
    _isScanning = false;
    _socket?.close();
    _socket = null;
  }

  /// Envoie une requête de découverte en broadcast
  Future<void> _sendBroadcast() async {
    try {
      // Obtient l'adresse de broadcast du réseau local
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLinkLocal: false,
      );

      for (var interface in interfaces) {
        // Calcule l'adresse de broadcast
        final addr = interface.addresses.firstWhere(
          (a) => !a.isLoopback && !a.isLinkLocal,
          orElse: () => InternetAddress('0.0.0.0'),
        );

        if (addr.type == InternetAddressType.IPv4) {
          // Calcule l'adresse de broadcast (remplace le dernier octet par 255)
          final parts = addr.address.split('.');
          final broadcastAddr = '${parts[0]}.${parts[1]}.${parts[2]}.255';

          final message = '$broadcastIdentifier:SCAN_REQUEST';
          final data = message.codeUnits;

          _socket?.send(
            data,
            InternetAddress(broadcastAddr),
            broadcastPort,
          );

          debugPrint('Broadcast envoyé vers $broadcastAddr:$broadcastPort');
        }
      }
    } catch (e) {
      debugPrint('Erreur envoi broadcast: $e');
    }
  }

  /// Gère les réponses de découverte
  void _handleDiscoveryResponse(Datagram datagram) {
    try {
      final data = String.fromCharCodes(datagram.data);
      final parts = data.split(':');

      if (parts.length >= 3 && parts[0] == broadcastIdentifier) {
        if (parts[1] == 'SCAN_RESPONSE') {
          // Parse la réponse: IBZUNG_DISCOVER:SCAN_RESPONSE:IP:PORT:ROOM_CODE:HOST_NAME
          final ip = parts[2];
          final port = int.tryParse(parts[3]) ?? 8080;
          final roomCode = parts.length > 4 ? parts[4] : null;
          final hostName = parts.length > 5 ? parts[5] : null;

          // Évite les doublons
          final key = '$ip:$port';
          if (!_lastSeen.containsKey(key) ||
              DateTime.now().difference(_lastSeen[key]!) > scanTimeout) {

            _lastSeen[key] = DateTime.now();

            final room = DiscoveredRoom(
              ipAddress: ip,
              port: port,
              roomCode: roomCode,
              hostName: hostName,
            );

            // Ajoute à la liste si pas déjà présente
            if (!_discoveredRooms.any((r) => r.ipAddress == ip && r.port == port)) {
              _discoveredRooms.add(room);
              debugPrint('Salle découverte: $room');
              onRoomDiscovered?.call(room);
            }
          }
        }
      }
    } catch (e) {
      debugPrint('Erreur parsing réponse: $e');
    }
  }

  /// Timer pour nettoyer les salles anciennes
  void _startCleanupTimer() {
    Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isScanning) {
        timer.cancel();
        return;
      }

      final now = DateTime.now();
      final expiredKeys = <String>[];

      _lastSeen.forEach((key, lastSeen) {
        if (now.difference(lastSeen) > const Duration(seconds: 5)) {
          expiredKeys.add(key);
        }
      });

      for (var key in expiredKeys) {
        _lastSeen.remove(key);
        final parts = key.split(':');
        if (parts.length >= 2) {
          final ip = parts[0];
          final port = int.tryParse(parts[1]) ?? 8080;

          final roomIndex = _discoveredRooms.indexWhere(
            (r) => r.ipAddress == ip && r.port == port,
          );

          if (roomIndex >= 0) {
            final room = _discoveredRooms.removeAt(roomIndex);
            onRoomRemoved?.call(room.ipAddress);
          }
        }
      }
    });
  }

  /// Ferme le service
  void dispose() {
    stopScan();
  }
}

/// Extension du WiFiService pour supporter le scan réseau
/// Cette classe sera mixée avec WiFiService
class NetworkScannerMixin {
  NetworkDiscoveryService? _discoveryService;
  bool _isScanning = false;
  final List<DiscoveredRoom> _scannedRooms = [];

  bool get isScanning => _isScanning;
  List<DiscoveredRoom> get scannedRooms => List.unmodifiable(_scannedRooms);

  /// Démarre le scan du réseau pour trouver des salles
  Future<void> startNetworkScan() async {
    if (_isScanning) return;

    _isScanning = true;
    _scannedRooms.clear();

    _discoveryService = NetworkDiscoveryService();

    _discoveryService!.onRoomDiscovered = (room) {
      if (!_scannedRooms.any((r) => r.ipAddress == room.ipAddress && r.port == room.port)) {
        _scannedRooms.add(room);
        debugPrint('Salle scannée ajoutée: ${room.ipAddress}');
      }
    };

    _discoveryService!.onRoomRemoved = (ipAddress) {
      _scannedRooms.removeWhere((r) => r.ipAddress == ipAddress);
    };

    await _discoveryService!.startScan();

    // Arrête le scan après 5 secondes
    await Future.delayed(const Duration(seconds: 5));
    stopNetworkScan();
  }

  /// Arrête le scan réseau
  void stopNetworkScan() {
    _isScanning = false;
    _discoveryService?.dispose();
    _discoveryService = null;
  }

  /// Méthode pour ajouter un hôte de broadcast sur le serveur
  /// Cette méthode sera appelée par le serveur IbizunguSocketServer
  static void enableServerBroadcast(IbizunguSocketServer server, String localIp, String roomCode, String hostName) {
    // Le serveur IbizunguSocketServer doit écouter sur le port 8081 (UDP)
    // et répondre aux requêtes de découverte
    // Cette fonctionnalité sera implémentée séparément
    debugPrint('Server broadcast enabled for $localIp:$roomCode');
  }
}
