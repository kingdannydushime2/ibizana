import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

/// Service OCR en ligne pour la vérification des transactions Lumicash
/// Utilise une API OCR externe pour analyser les screenshots de SMS
class OnlineOcrService {
  // Clé API OCR.space (gratuite, limite 500 requêtes/heure)
  // Alternative: utiliser le endpoint gratuit sans clé avec limite
  static const String _apiUrl = 'https://api.ocr.space/parse/image';

  // Headers par défaut pour les requêtes
  static const Map<String, String> _defaultHeaders = {
    'apikey': 'K87944574888957', // Clé API gratuite demo
  };

  /// Vérifie si une image contient le message de confirmation Lumitel
  /// Retourne un tuple (bool isValid, String? message)
  Future<(bool, String?)> verifyLumitelTransaction(
    File imageFile,
    int expectedAmount,
  ) async {
    try {
      // Étape 1: Envoyer l'image à l'API OCR
      final ocrResult = await _performOcr(imageFile);

      if (ocrResult == null) {
        return (false, 'Impossible de lire l\'image. Veuillez réessayer avec une capture plus claire.');
      }

      final fullText = ocrResult.toLowerCase();

      // Message attendu dans le SMS LUMITEL
      // Format: "Message de LUMITEL : votre transaction de {montant}FBU a réussi"
      final expectedPatterns = [
        'lumitel',
        'transaction',
        'a réussi',
        '${expectedAmount}fbu',
      ];

      // Vérifie que tous les éléments sont présents
      bool hasLumitel = fullText.contains('lumitel');
      bool hasTransaction = fullText.contains('transaction');
      bool hasSuccess = fullText.contains('a réussi') || fullText.contains('reussi');
      bool hasAmount = fullText.contains('${expectedAmount}fbu') ||
                       fullText.contains('${expectedAmount} fbu') ||
                       fullText.contains('${expectedAmount}fb') ||
                       fullText.contains('${expectedAmount}.00fbu');

      if (hasLumitel && hasTransaction && hasSuccess && hasAmount) {
        return (true, 'Transaction vérifiée avec succès !');
      }

      // Message d'erreur opaque pour éviter de dévoiler les critères de recherche
      return (false, 'Validation impossible. Assurez-vous que la capture d\'écran est nette et contient le SMS complet de confirmation LUMITEL.');

    } catch (e) {
      debugPrint('Erreur OCR: $e');
      return (false, 'Une erreur technique est survenue. Veuillez réessayer plus tard.');
    }
  }

  /// Effectue l'OCR sur l'image via l'API OCR.space
  Future<String?> _performOcr(File imageFile) async {
    try {
      // Lire l'image comme bytes
      final bytes = await imageFile.readAsBytes();
      final base64Image = base64Encode(bytes);

      // Créer la requête multipart
      final request = http.MultipartRequest('POST', Uri.parse(_apiUrl));

      // Ajouter les headers
      request.headers.addAll(_defaultHeaders);

      // Ajouter l'image en base64
      request.fields['base64Image'] = 'data:image/jpeg;base64,$base64Image';

      // Configurer les options OCR
      request.fields['language'] = 'fre'; // Français
      request.fields['isOverlayRequired'] = 'false';
      request.fields['detectOrientation'] = 'true';
      request.fields['scale'] = 'true';
      request.fields['OCREngine'] = '2'; // Engine 2 = plus précis

      // Envoyer la requête
      final streamedResponse = await request.send().timeout(
        const Duration(seconds: 30),
        onTimeout: () {
          throw TimeoutException('La requête OCR a expiré');
        },
      );

      // Lire la réponse
      final response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(response.body);

        // Vérifier si l'OCR a réussi
        if (jsonResponse['IsErroredOnProcessing'] == true) {
          debugPrint('OCR Error: ${jsonResponse['ErrorMessage']}');
          return null;
        }

        // Extraire le texte reconnu
        final parsedResults = jsonResponse['ParsedResults'] as List?;
        if (parsedResults != null && parsedResults.isNotEmpty) {
          return parsedResults[0]['ParsedText'] as String?;
        }
      }

      debugPrint('OCR API error: ${response.statusCode}');
      return null;
    } catch (e) {
      debugPrint('Erreur performing OCR: $e');
      return null;
    }
  }

  /// Alternative: Vérification par texte simulé (sans OCR)
  /// Utile si l'API OCR n'est pas disponible
  Future<(bool, String?)> verifyWithManualInput(
    String manualText,
    int expectedAmount,
  ) async {
    final fullText = manualText.toLowerCase();

    bool hasLumitel = fullText.contains('lumitel');
    bool hasTransaction = fullText.contains('transaction');
    bool hasSuccess = fullText.contains('a réussi') || fullText.contains('reussi');
    bool hasAmount = fullText.contains('${expectedAmount}fbu') ||
                     fullText.contains('${expectedAmount} fbu') ||
                     fullText.contains('${expectedAmount}fb');

    if (hasLumitel && hasTransaction && hasSuccess && hasAmount) {
      return (true, 'Transaction vérifiée! Informations Lumitel confirmées.');
    }

    List<String> missing = [];
    if (!hasLumitel) missing.add('lumitel');
    if (!hasTransaction) missing.add('transaction');
    if (!hasSuccess) missing.add('confirmation de succès');
    if (!hasAmount) missing.add('montant $expectedAmount FBU');

    return (false, 'Message incomplet. Éléments manquants: ${missing.join(", ")}');
  }
}

/// Exception pour les timeouts
class TimeoutException implements Exception {
  final String message;
  TimeoutException(this.message);

  @override
  String toString() => 'TimeoutException: $message';
}
