import 'package:flutter/material.dart';
import '../models/models.dart';
import '../utils/theme.dart';

/// Widget d'affichage d'une carte de jeu réaliste
class CardWidget extends StatelessWidget {
  final PlayingCard? card;
  final bool isFaceDown;
  final bool isSelected;
  final double size;
  final VoidCallback? onTap;

  const CardWidget({
    super.key,
    this.card,
    this.isFaceDown = false,
    this.isSelected = false,
    this.size = 80,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: size,
        height: size * 1.4,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(size * 0.1),
          boxShadow: [
            // Ombre principale
            BoxShadow(
              color: isSelected
                  ? AppTheme.primaryGold.withValues(alpha: 0.6)
                  : Colors.black.withValues(alpha: 0.4),
              blurRadius: isSelected ? 16 : 8,
              offset: Offset(0, isSelected ? 6 : 4),
              spreadRadius: isSelected ? 2 : 0,
            ),
            // Reflet subtil
            BoxShadow(
              color: Colors.white.withValues(alpha: 0.1),
              blurRadius: 2,
              offset: const Offset(0, -1),
            ),
          ],
          transform: isSelected
              ? (Matrix4.identity()..translate(0.0, -12.0))
              : Matrix4.identity(),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(size * 0.1),
          child: isFaceDown ? _buildCardBack() : _buildCardFront(),
        ),
      ),
    );
  }

  Widget _buildCardBack() {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF1E3A5F),
            const Color(0xFF0D1F33),
          ],
        ),
      ),
      child: Stack(
        children: [
          // Motif de dos de carte - losanges
          CustomPaint(
            size: Size(size, size * 1.4),
            painter: _CardBackPatternPainter(),
          ),
          // Bordure dorée
          Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: AppTheme.primaryGold.withValues(alpha: 0.6),
                width: 2,
              ),
              borderRadius: BorderRadius.circular(size * 0.1),
            ),
          ),
          // Centre avec logo
          Center(
            child: Container(
              width: size * 0.5,
              height: size * 0.5,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppTheme.primaryGold.withValues(alpha: 0.4),
                  width: 2,
                ),
              ),
              child: const Center(
                child: Text(
                  'IBZ',
                  style: TextStyle(
                    color: AppTheme.primaryGold,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getRankChar(CardRank rank) {
    switch (rank) {
      case CardRank.ace: return 'A';
      case CardRank.king: return 'K';
      case CardRank.queen: return 'Q';
      case CardRank.jack: return 'J';
      case CardRank.seven: return '7';
      case CardRank.six: return '6';
    }
  }

  Widget _buildCardFront() {
    if (card == null) return _buildEmptyCard();

    final isRed = card!.suit == CardSuit.hearts || card!.suit == CardSuit.diamonds;
    final textColor = isRed ? AppTheme.cardRed : AppTheme.cardBlack;
    final rankChar = _getRankChar(card!.rank);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(size * 0.05),
        border: Border.all(color: Colors.grey.shade300, width: 0.5),
      ),
      child: Stack(
        children: [
          // Index haut gauche
          Positioned(
            top: size * 0.05,
            left: size * 0.05,
            child: _buildIndex(rankChar, card!.suitSymbol, textColor),
          ),
          
          // Index bas droit (inversé)
          Positioned(
            bottom: size * 0.05,
            right: size * 0.05,
            child: Transform.rotate(
              angle: 3.14159,
              child: _buildIndex(rankChar, card!.suitSymbol, textColor),
            ),
          ),
          
          // Centre de la carte
          Container(
            margin: EdgeInsets.all(size * 0.25),
            child: _buildCardCenter(textColor),
          ),

          // Marqueur Ibimari (Étoile discrète)
          if (card!.isIbimari)
            Positioned(
              top: 2,
              right: 2,
              child: Icon(Icons.star, size: size * 0.08, color: AppTheme.primaryGold.withValues(alpha: 0.5)),
            ),
        ],
      ),
    );
  }

  Widget _buildIndex(String rank, String suit, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          rank,
          style: TextStyle(
            color: color,
            fontSize: size * 0.16,
            fontWeight: FontWeight.bold,
            fontFamily: 'Georgia',
            height: 1,
          ),
        ),
        Text(
          suit,
          style: TextStyle(color: color, fontSize: size * 0.12, height: 1),
        ),
      ],
    );
  }

  Widget _buildCardCenter(Color color) {
    switch (card!.rank) {
      case CardRank.ace:
        return Center(
          child: Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.5, color: color)),
        );
      case CardRank.six:
        return _buildPips(6, color);
      case CardRank.seven:
        return _buildPips(7, color);
      case CardRank.king:
      case CardRank.queen:
      case CardRank.jack:
        return _buildFaceCard(color);
    }
  }

  Widget _buildPips(int count, Color color) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.15, color: color)),
            if (count == 7)
               Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.15, color: color))
            else const SizedBox(width: 15),
            Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.15, color: color)),
          ],
        ),
        if (count == 7)
          Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.15, color: color)),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.15, color: color)),
            const SizedBox(width: 15),
            Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.15, color: color)),
          ],
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.15, color: color)),
            const SizedBox(width: 15),
            Text(card!.suitSymbol, style: TextStyle(fontSize: size * 0.15, color: color)),
          ],
        ),
      ],
    );
  }

  Widget _buildFaceCard(Color color) {
    IconData faceIcon;
    if (card!.rank == CardRank.king) faceIcon = Icons.person;
    else if (card!.rank == CardRank.queen) faceIcon = Icons.face_3;
    else faceIcon = Icons.shield;

    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: color.withValues(alpha: 0.3), width: 1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: ClipRect(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: Icon(faceIcon, size: size * 0.3, color: color.withValues(alpha: 0.8)),
              ),
            ),
            Divider(height: 1, color: color.withValues(alpha: 0.3)),
            Expanded(
              child: Transform.rotate(
                angle: 3.14159,
                child: Center(
                  child: Icon(faceIcon, size: size * 0.3, color: color.withValues(alpha: 0.8)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(size * 0.05),
      ),
    );
  }
}
}
}

/// Peintre personnalisé pour le motif du dos de carte
class _CardBackPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.primaryGold.withValues(alpha: 0.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    // Dessine des losanges
    final spacing = size.width * 0.15;
    final rows = (size.height / spacing).ceil();
    final cols = (size.width / spacing).ceil();

    for (int row = 0; row < rows; row++) {
      for (int col = 0; col < cols; col++) {
        final x = col * spacing + (row.isOdd ? spacing / 2 : 0);
        final y = row * spacing;

        if (x >= 0 && x < size.width && y >= 0 && y < size.height) {
          final path = Path()
            ..moveTo(x, y - spacing / 4)
            ..lineTo(x + spacing / 4, y)
            ..lineTo(x, y + spacing / 4)
            ..lineTo(x - spacing / 4, y)
            ..close();

          canvas.drawPath(path, paint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
